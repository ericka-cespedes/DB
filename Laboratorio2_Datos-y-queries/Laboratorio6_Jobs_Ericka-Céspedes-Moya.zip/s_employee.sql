-- Create sequence 
create sequence S_EMPLOYEE
minvalue 1
maxvalue 1000000
start with 1
increment by 1
nocache;
