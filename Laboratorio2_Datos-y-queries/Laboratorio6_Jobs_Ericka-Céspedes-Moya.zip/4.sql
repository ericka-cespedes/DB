select * from DBA_SCHEDULER_JOB_LOG
where owner ='GE'
and job_name = 'A01'
